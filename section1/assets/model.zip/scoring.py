import pickle

def load_model():
    with open("model.pkl", "rb") as f:
        return pickle.load(f)

model = load_model()

def score(payload):
    X = payload["input"]
    preds = model.predict(X)
    return {"predictions": preds.tolist()}
